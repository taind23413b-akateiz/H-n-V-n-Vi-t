# Hướng dẫn deploy `Hồn Văn Việt` lên Render

## 1. Chuẩn bị

Bạn đã có sẵn toàn bộ project:

- `server.js`
- `package.json`
- `render.yaml`
- `index.html`
- `admin.html`
- `styles.css`
- `script.js`
- `admin.js`
- `data/registrations.json`

Nếu cần, dùng file nén này:

- `hon-van-viet-dynamic.zip`

## 2. Đưa mã nguồn lên GitHub

### Cách nhanh nhất

1. Tạo một repository mới trên GitHub, ví dụ: `hon-van-viet`.
2. Tải toàn bộ các file trong project này lên repository đó.
3. Đảm bảo các file nằm ở thư mục gốc của repo, không đặt trong thư mục con.

## 3. Tạo web service trên Render

1. Vào [https://render.com](https://render.com)
2. Đăng nhập bằng GitHub
3. Chọn `New +`
4. Chọn `Web Service`
5. Chọn repository GitHub vừa tạo

## 4. Cấu hình trên Render

Nếu Render tự đọc `render.yaml` thì chỉ cần xác nhận và deploy.

Nếu bạn phải điền tay, dùng các giá trị sau:

- Name: `hon-van-viet`
- Runtime: `Node`
- Build Command: để trống
- Start Command: `npm start`

## 5. Biến môi trường

Thêm biến môi trường:

- Key: `ADMIN_KEY`
- Value: `honvanviet-admin`

Bạn có thể đổi giá trị này sang chuỗi riêng để bảo mật tốt hơn.

Ví dụ:

- `ADMIN_KEY = vanviet-2026-bao-mat`

Khi đó trang quản trị sẽ là:

- `https://ten-mien-cua-ban.onrender.com/admin?key=vanviet-2026-bao-mat`

## 6. Deploy

1. Bấm `Create Web Service`
2. Chờ Render build và chạy
3. Sau khi hoàn tất, bạn sẽ nhận được một link public dạng:

`https://ten-du-an.onrender.com`

## 7. Kiểm tra sau deploy

Mở các link sau:

- Trang chủ: `https://ten-du-an.onrender.com`
- Trang quản trị: `https://ten-du-an.onrender.com/admin?key=honvanviet-admin`

Thử:

1. Điền form đăng ký ở trang chủ
2. Bấm gửi
3. Mở trang quản trị để xem dữ liệu có xuất hiện không

## 8. Lưu ý quan trọng

Hiện tại dữ liệu đang lưu trong file `data/registrations.json`.

Điều này có nghĩa là:

- phù hợp để demo hoặc chạy bản thử nghiệm
- không phù hợp để lưu dữ liệu lâu dài trên môi trường production

Nếu bạn muốn chạy thật lâu dài, bước tiếp theo nên là:

1. chuyển dữ liệu sang `MongoDB`, `Supabase` hoặc `PostgreSQL`
2. thêm đăng nhập cho trang quản trị
3. thêm gửi email hoặc đổ dữ liệu vào Google Sheets

## 9. Nếu muốn nhanh hơn

Bạn có thể dùng repo GitHub rồi deploy ngay theo đúng cấu hình hiện tại vì project đã có sẵn `render.yaml`.

Sau đó chỉ cần thêm `ADMIN_KEY` là gần như xong.
