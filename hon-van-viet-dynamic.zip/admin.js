const params = new URLSearchParams(window.location.search);
const adminKey = params.get("key") || "honvanviet-admin";

const totalElement = document.querySelector("#admin-total");
const todayElement = document.querySelector("#admin-today");
const latestElement = document.querySelector("#admin-latest");
const messageElement = document.querySelector("#admin-message");
const tableBody = document.querySelector("#admin-table-body");
const refreshButton = document.querySelector("#refresh-admin");

function formatDateTime(value) {
  if (!value) return "Chưa có";

  return new Intl.DateTimeFormat("vi-VN", {
    dateStyle: "short",
    timeStyle: "short"
  }).format(new Date(value));
}

function renderRows(registrations) {
  if (!registrations.length) {
    tableBody.innerHTML = `
      <tr>
        <td colspan="5">Chưa có đăng ký nào.</td>
      </tr>
    `;
    return;
  }

  tableBody.innerHTML = registrations
    .map((item) => `
      <tr>
        <td>${item.fullName}</td>
        <td>${item.phone}</td>
        <td>${item.grade}</td>
        <td>${item.note || "Không có"}</td>
        <td>${formatDateTime(item.createdAt)}</td>
      </tr>
    `)
    .join("");
}

async function loadRegistrations() {
  messageElement.textContent = "Đang tải dữ liệu...";
  messageElement.className = "admin-message";

  try {
    const [overviewResponse, registrationsResponse] = await Promise.all([
      fetch("/api/overview"),
      fetch(`/api/registrations?key=${encodeURIComponent(adminKey)}`)
    ]);

    const overview = await overviewResponse.json();
    const registrationsPayload = await registrationsResponse.json();

    if (!overviewResponse.ok || !registrationsResponse.ok) {
      throw new Error(registrationsPayload.message || "Không thể tải dữ liệu quản trị.");
    }

    totalElement.textContent = overview.totalRegistrations;
    todayElement.textContent = overview.todayRegistrations;
    latestElement.textContent = formatDateTime(overview.latestRegistrationAt);

    renderRows(registrationsPayload.registrations);
    messageElement.textContent = `Đã tải ${registrationsPayload.registrations.length} đăng ký.`;
    messageElement.className = "admin-message success";
  } catch (error) {
    messageElement.textContent = error.message || "Không thể tải dữ liệu quản trị.";
    messageElement.className = "admin-message error";
  }
}

refreshButton?.addEventListener("click", loadRegistrations);

loadRegistrations();
