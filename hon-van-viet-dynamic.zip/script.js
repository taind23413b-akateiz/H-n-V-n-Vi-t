const testimonials = Array.from(document.querySelectorAll(".testimonial"));
const dots = Array.from(document.querySelectorAll(".dot"));
const form = document.querySelector("#registration-form");
const submitButton = document.querySelector("#submit-button");
const feedbackElement = document.querySelector("#form-feedback");
const totalRegistrationsElement = document.querySelector("#total-registrations");
const todayRegistrationsElement = document.querySelector("#today-registrations");
const recentRegistrationsElement = document.querySelector("#recent-registrations");

let activeIndex = 0;
let intervalId = null;

function setActiveSlide(index) {
  testimonials.forEach((item, idx) => {
    item.classList.toggle("is-active", idx === index);
  });

  dots.forEach((dot, idx) => {
    dot.classList.toggle("is-active", idx === index);
    dot.setAttribute("aria-selected", idx === index ? "true" : "false");
  });

  activeIndex = index;
}

function nextSlide() {
  const nextIndex = (activeIndex + 1) % testimonials.length;
  setActiveSlide(nextIndex);
}

function startAutoRotate() {
  if (intervalId) clearInterval(intervalId);
  intervalId = setInterval(nextSlide, 4200);
}

function formatTime(value) {
  if (!value) return "";

  return new Intl.DateTimeFormat("vi-VN", {
    dateStyle: "short",
    timeStyle: "short"
  }).format(new Date(value));
}

function renderRecentRegistrations(items = []) {
  if (!recentRegistrationsElement) return;

  if (!items.length) {
    recentRegistrationsElement.innerHTML = "<p>Chưa có đăng ký nào.</p>";
    return;
  }

  recentRegistrationsElement.innerHTML = items
    .map((item) => `
      <article class="recent-item">
        <strong>${item.fullName}</strong>
        <span>${item.grade}</span>
        <small>${formatTime(item.createdAt)}</small>
      </article>
    `)
    .join("");
}

async function loadOverview() {
  try {
    const response = await fetch("/api/overview");
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || "Không thể tải dữ liệu.");
    }

    if (totalRegistrationsElement) {
      totalRegistrationsElement.textContent = data.totalRegistrations;
    }

    if (todayRegistrationsElement) {
      todayRegistrationsElement.textContent = data.todayRegistrations;
    }

    renderRecentRegistrations(data.recentRegistrations || []);
  } catch (error) {
    renderRecentRegistrations([]);
  }
}

async function handleSubmit(event) {
  event.preventDefault();

  if (!form) return;

  const formData = new FormData(form);
  const payload = {
    fullName: formData.get("fullName"),
    phone: formData.get("phone"),
    grade: formData.get("grade"),
    note: formData.get("note")
  };

  submitButton.disabled = true;
  submitButton.textContent = "Đang gửi...";
  feedbackElement.textContent = "";
  feedbackElement.className = "form-feedback";

  try {
    const response = await fetch("/api/registrations", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || "Không thể gửi đăng ký.");
    }

    feedbackElement.textContent = data.message;
    feedbackElement.className = "form-feedback success";
    form.reset();
    await loadOverview();
  } catch (error) {
    feedbackElement.textContent = error.message || "Không thể gửi đăng ký.";
    feedbackElement.className = "form-feedback error";
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = "Nhận lịch học thử";
  }
}

dots.forEach((dot, idx) => {
  dot.addEventListener("click", () => {
    setActiveSlide(idx);
    startAutoRotate();
  });
});

form?.addEventListener("submit", handleSubmit);

setActiveSlide(0);
startAutoRotate();
loadOverview();
